﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmClsUsuario : Form
    {
        protected Usuario usu;
        private Cliente cli;
        protected int ultimo = 0;     

        public frmClsUsuario()
        {
            InitializeComponent();            
        }

        public Usuario Usu
        {
            get { return usu; }
        }

        public Cliente Cli
        {
            get { return cli; }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar_controles();
        }
        //Limpiar valores en componentes.
        private void Limpiar_controles()
        {
            this.txtNombre.Text = "";
            this.txtApellido.Text = "";
            this.txtDni.Text = "";
            this.cmbCalle.Text = "";
            this.txtAltura.Text = "0";
            this.cmbLocalidad.Text = "";
            this.cmbPartido.Text = "";
            this.btnActualizar.Enabled = false;
            this.btnIngresar.Enabled = true;            
        }
        private void btnSalir_Click(object sender, EventArgs e)
        {            
            this.Close();
            this.btnIngresar.Enabled = true;
        }


    }
}
