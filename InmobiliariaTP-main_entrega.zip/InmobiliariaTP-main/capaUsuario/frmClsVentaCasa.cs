﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmClsVentaCasa : Form
    {        
        Inmobiliaria iventa = new Inmobiliaria("inmo");
        Inmobiliaria icom = new Inmobiliaria("inmo");
        private Inmobiliaria icli;
        private Inmobiliaria iven;
        private Inmobiliaria isuc;
        private Inmobiliaria ires; //Si esta Reservada        
        private Casa casa;
        private Venta venta;
        private Reserva res;
        private Comision comision;

        public frmClsVentaCasa(Casa c, Reserva r)
        {
            icli = Inmobiliaria.Recuperar("Cliente.dat");
            iven = Inmobiliaria.Recuperar("Vendedor.dat");
            isuc = Inmobiliaria.Recuperar("Sucursal.dat");
            icom = Inmobiliaria.Recuperar("Comision.dat");

            InitializeComponent();                  
            if (c != null)
                CargarUsuario(c);
            casa = c;
            res = r;           

            //Cargar List y DataView.

            CargarCompView();
            CargarCompViewV();  
            CargarCompViewS();
            CargarCompViewR();
        }
        public Venta Venta
        {
            get { return venta; }
        }
        public Comision UnaComision
        {
            get { return comision; }
        }
        private void CargarUsuario(Casa c)
        {
            try
            {
                this.textBoxCalle.Text = c.Calle;
                this.textBoxNumero.Text = c.Nro.ToString();
                this.textBoxLocalidad.Text = c.Localidad;
                this.textBoxPartido.Text = c.Partido;
                this.textBoxProvincia.Text = c.Provincia;
                this.textBoxTotalM2.Text = c.M2Terreno.ToString();
                this.textBoxM2Cubiertos.Text = c.M2Cubiertos.ToString();
                this.txtIdCasa.Text = c.Id;                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void lblSucursal_Click(object sender, EventArgs e)
        {
            Sucursal s = (Sucursal)lstTablaS.SelectedItem;
            if(s != null)
                txtCostoSucLoc.Text = s.Preciom2.ToString();
                lblDatosUbicacion.Text = s.Partido + "/" + s.Localidad;
                txtSucursal.Text = s.IdSucursal.ToString();

            btnCostoTot.Enabled = true;
        }
        private void lstTablaC_Click(object sender, EventArgs e)
        {
            Cliente c = (Cliente)lstTablaC.SelectedItem;
            if (c != null)
                txtCliente.Text = c.NroCli;
        }
        private void lstTablaV_Click(object sender, EventArgs e)
        {
            Vendedor v = (Vendedor)lstTablaV.SelectedItem;
            if (v != null)
                txtVendedor.Text = v.Legajo.ToString();
        }
        private void btnOperacion_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtCliente.Text != "" && txtVendedor.Text != "")
                {
                    string cli = txtCliente.Text;
                    string inm = txtIdCasa.Text;
                    int leg = int.Parse(txtVendedor.Text);
                    int suc = int.Parse(txtSucursal.Text);
                    double costo = double.Parse(txtCostoTotal.Text);
                    venta = new Venta(cli, inm, leg, suc, costo);

                    iventa.AgregarUnaVenta(venta);

                    //Elimino reserva con la venta.
                    Reserva r = (Reserva)lstTablaR.SelectedItem;
                    if (r != null)
                    {
                        ires.EliminarReserva(r);
                        ires.guardarReserva();
                    }
                    //Genero el registro de comisión.
                    GenerarComision();

                    MessageBox.Show("Se registro correctamente la venta.");

                    btnSalir_Click(sender, e);
                }
                else
                {
                    MessageBox.Show("Debe cargar el cliente y/o vendedor para la operación de venta.");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void GenerarComision()
        {
            Cliente cli = (Cliente)lstTablaC.SelectedItem;
            Vendedor ven = (Vendedor)lstTablaV.SelectedItem;
            Sucursal suc = (Sucursal)lstTablaS.SelectedItem;

            Vivienda vi = new Casa(casa.Calle, casa.Nro,casa.Localidad, casa.Partido, casa.Provincia,casa.M2Cubiertos,casa.M2Terreno,casa.Id,
                            casa.EsAlquiler, casa.EsVenta);

            comision = new Comision(cli, vi, ven, suc, double.Parse(txtComisión.Text),"VENTA");

            if(comision != null)
            {
                icom.AgregarComision(comision);
                icom.guardarComision();
            }
        }
        private void CargarCompViewS()
        {
            Inmobiliaria isucaux = new Inmobiliaria("inmo");
            for (var i = 0; i < isuc.ListaSucural.Count; i++)
            {
                Sucursal s = isuc.ListaSucural[i];
                if (s.Localidad == casa.Localidad)
                {
                    isucaux.AgregarSucursal(s);

                    txtCostoSucLoc.Text = s.Preciom2.ToString();
                    txtSucursal.Text = s.IdSucursal.ToString();
                    //Calcula es costo total de la Casa
                    txtCostoTotal.Text = casa.Costo_Total(s.Preciom2).ToString();
                    txtComisión.Text = casa.ComisionVta(double.Parse(txtCostoTotal.Text)).ToString();
                }              
            }
            //Cargar ListBox.
            lstTablaS.DataSource = null;
            lstTablaS.DataSource = isucaux.ListaSucural;
            lstTablaS.Select();

            //Cargar DataGridView.
            dtgViewTablaSuc.DataSource = null;
            dtgViewTablaSuc.DataSource = isucaux.ListaSucural;
            dtgViewTablaSuc.Select();
        }
        private void CargarCompView()
        {
            Inmobiliaria icliaux = new Inmobiliaria("inmo");
            if (res != null)
            {                
                for (var i = 0; i < icli.ListaClientes.Count; i++)
                {
                    Cliente c = icli.ListaClientes[i];
                    if (c.NroCli == res.ClienteReserva.NroCli)
                    {
                        icliaux.AgregarCliente(c);
                    }
                    //Carga al Cliente.
                    txtCliente.Text = res.ClienteReserva.NroCli;
                }
            }
            else
            {
                icliaux = icli;
            }
            //Cargar ListBox.
            lstTablaC.DataSource = null;
            lstTablaC.DataSource = icliaux.ListaClientes;
            lstTablaC.ClearSelected();

            //Cargar DataGridView.
            dtgViewTablaCli.DataSource = null;
            dtgViewTablaCli.DataSource = icliaux.ListaClientes;
            dtgViewTablaCli.ClearSelection();
        }
        private void CargarCompViewV()
        {
            //Cargar ListBox.
            lstTablaV.DataSource = null;
            lstTablaV.DataSource = iven.ListaVendedor;
            lstTablaV.ClearSelected();

            //Cargar DataGridView.
            dtgViewTablaVen.DataSource = null;
            dtgViewTablaVen.DataSource = iven.ListaVendedor;
            dtgViewTablaVen.ClearSelection();
        }
        private void CargarCompViewR()
        {
            Inmobiliaria reserva = new Inmobiliaria("inmo");
            reserva.AgregarReserva(res);
            ires = reserva;
            //Cargar ListBox.
            lstTablaR.DataSource = null;
            lstTablaR.DataSource = reserva.Reserva;
            lstTablaR.Select();

            //Cargar DataGridView.
            dtgViewTablaRes.DataSource = null;
            dtgViewTablaRes.DataSource = reserva.Reserva;
            dtgViewTablaRes.ClearSelection();
        }
        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
