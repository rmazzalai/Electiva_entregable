﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmAlquiler : Form
    {
        private Inmobiliaria icasa;
        private Inmobiliaria idpto;
        private Inmobiliaria ialq;
        private Inmobiliaria icom;

        public frmAlquiler()
        {
            icasa = Inmobiliaria.Recuperar("Casa.dat");
            idpto = Inmobiliaria.Recuperar("Departamento.dat");
            ialq = Inmobiliaria.Recuperar("Alquiler.dat");
            icom = Inmobiliaria.Recuperar("Comision.dat");

            InitializeComponent();
            //Cargar List y DataView.
            CargarCompViewC();
            CargarCompViewD();
            CargarCompViewO();
        }
        //-----------------------Casa------------------------
        private void btnAlquilerCasa_Click(object sender, EventArgs e)
        {
            Casa c = (Casa)lstTablaC.SelectedItem;
            if (c != null)
            {
                frmClsAlquilerCasa agregar = new frmClsAlquilerCasa(c);
                CargarInfoC(agregar, c);

                icom = Inmobiliaria.Recuperar("Comision.dat");
            }
            else
                MessageBox.Show("No selecciono una Vivienda/Casa");
        }
        private void CargarInfoC(frmClsAlquilerCasa agregar, Casa c)
        {
            agregar.ShowDialog();

            Alquiler a = agregar.Alquiler;
            if (a != null)
            {
                //Carga la venta.
                ialq.AgregarUnAlquiler(a);

                //Cambia el estado de la Casa.
                c.Estado = "A";
                //Guarda nuevos valores(estados), en Casa.
                icasa.guardarCasa();

                //Carga la casa vendida.
                ialq.guardarAlquiler();

                //Cargar List y DataView.
                CargarCompViewO();
                CargarCompViewC();
            }
        }
        //-----------------------Departamento------------------------
        //Asocia y muestra si tiene una comision con esa venta. 
        private void lstTablaO_Click(object sender, EventArgs e)
        {
            //Trae la comisión por tipo de Vivienda.
            Alquiler a = (Alquiler)lstTablaO.SelectedItem;
            Inmobiliaria auxiliar = new Inmobiliaria("inmo");

            for (var i = 0; i < icom.CantComision(); i++)
            {
                Comision c = icom.ListaComisiones[i];
                if (a != null && icom != null)
                {
                    if (a.IdInmueble.Substring(0, 2) == "CA")
                    {// Es una Casa.
                        if (a != null) //&& c.IDVivienda == null
                        {
                            if (a.IdInmueble == c.IDVivienda.Id)
                            {
                                auxiliar.AgregarComision(c);
                                a = null;
                            }
                        }
                    }
                    else
                    {// Es ub Dpto.
                        
                    }
                }
            }
            //Cargar dataGridView.
            lstTablaOper.DataSource = null;
            lstTablaOper.DataSource = auxiliar.ListaComisiones;
            lstTablaOper.Select();
        }
        private void CargarCompViewC()
        {
            Inmobiliaria casaauxc = new Inmobiliaria("inmo");
            for (var i = 0; i < icasa.Casas.Count; i++)
            {
                Casa c = icasa.Casas[i];
                if ((c.Estado != "V" || c.Estado != "A") && c.EsAlquiler == true)
                {
                    casaauxc.agregarCasa(c);
                }
            }
            //Cargar ListBox Casa
            lstTablaC.DataSource = null;
            lstTablaC.DataSource = casaauxc.Casas;
            lstTablaC.ClearSelected();
        }
        private void CargarCompViewD()
        {
            Inmobiliaria dptoauxd = new Inmobiliaria("inmo");
            for (var i = 0; i < idpto.Dptos.Count; i++)
            {
                Dpto d = idpto.Dptos[i];
                if ((d.Estado != "V" || d.Estado != "A") && d.EsAlquiler == true)
                {
                    dptoauxd.agregarDpto(d);
                }
            }
            //Cargar ListBox.
            lstTablaD.DataSource = null;
            lstTablaD.DataSource = dptoauxd.Dptos;
            lstTablaD.ClearSelected();
        }
        private void CargarCompViewO()
        {
            //Cargar ListBox.
            lstTablaO.DataSource = null;
            lstTablaO.DataSource = ialq.ListaAlquiler;
            lstTablaO.ClearSelected();

            //Cargar dataGridView.
            dtgViewTablaO.DataSource = null;
            dtgViewTablaO.DataSource = ialq.ListaAlquiler;
            dtgViewTablaO.ClearSelection();
        }
        private void CargarCompView()
        {
            //Cargar ListBox.
            lstTablaC.DataSource = null;
            lstTablaC.DataSource = icasa.Casas;
            lstTablaC.ClearSelected();
        }
        private void GuardarICasa()
        {
            if (icasa.guardarCasa() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void GuardarIDpto()
        {
            if (idpto.guardarDepartamento() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void GuardarIAlquiler()
        {
            if (ialq.guardarAlquiler() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void GuardarIComision()
        {
            if (ialq.guardarComision() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void butSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
