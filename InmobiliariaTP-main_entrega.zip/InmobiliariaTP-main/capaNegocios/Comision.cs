﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capaNegocio
{
    [Serializable]
    public class Comision
    {
        private DateTime fcomision;
        private Cliente idCliente;
       //private Casa idCasa;
       // protected Dpto idDpto;
        private Vivienda iVivienda;
        private Vendedor idLegajo;
        private Sucursal idSucursal;
        private string concepto;
        private double comision;

        public Comision(Cliente idl, Vivienda ivi, Vendedor idleg, Sucursal idsuc, 
                    double c, string cpto)
        {
            this.idCliente = idl;
            //this.idCasa = idc;
            this.iVivienda = ivi;
            //this.idDpto = idd;
            this.idLegajo = idleg;
            this.idSucursal = idsuc;
            this.comision = c;
            this.fcomision = DateTime.Today;
            this.concepto = cpto;
        }
        public Cliente IdCliente
        {
            set { idCliente = value; }
            get { return idCliente; }
        }
        public Vivienda IDVivienda
        {
            set { iVivienda = value; }
            get { return this.iVivienda; }
        }
        public Vendedor IdLegajo
        {
            set { idLegajo = value; }
            get { return this.idLegajo; }
        }
        public Sucursal IdSucursal
        {
            set { idSucursal = value; }
            get { return this.idSucursal; }
        }
        public DateTime FComision
        {
            get { return fcomision; }
            set { this.fcomision = value; }
        }
        public string Concepto
        {
            set { concepto = value; }
            get { return this.concepto; }
        }
        public double ComisionVenta
        {
            set { comision = value; }
            get { return this.comision; }
        }
        public override string ToString()
        {
            var vivienda = " ";

            if (IDVivienda != null)
            {
                vivienda = IDVivienda.Id + " DIRECCION: " + IDVivienda.Calle + " " + IDVivienda.Nro + ", " + IDVivienda.Localidad + ", " + IDVivienda.Provincia;
            }
            
            return $" = {fcomision.ToString("dd/MM/yyyy")} {Concepto} {IdCliente.Apellido} {idCliente.Nombre} {idSucursal.Localidad} {vivienda}";
        }
    }
}
