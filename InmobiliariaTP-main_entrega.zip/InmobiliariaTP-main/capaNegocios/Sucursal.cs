﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capaNegocio
{
    [Serializable]
    public class Sucursal
    {
        protected string partido;
        protected string localidad;
        protected string provincia;
        protected int idSucursal;
        protected double valorm2;

        public Sucursal(string pr, string loc, string pv, 
                        int id, double xm2)
        {
            partido = pr;
            localidad = loc;
            provincia = pv;
            idSucursal = id;
            valorm2 = xm2;
        }

        public String Partido
        {
            set { partido = value; }
            get { return partido; }
        }
        public String Localidad
        {
            set { localidad = value; }
            get { return localidad; }
        }
        public String Provincia
        {
            set { provincia = value; }
            get { return provincia; }
        }
        public int IdSucursal
        {
            set { idSucursal = value; }
            get { return idSucursal; }
        }
        public double Preciom2
        {
            set { valorm2 = value; }
            get { return valorm2; }
        }
        public override string ToString()
        {
            return partido + " - " + idSucursal + " _ " + valorm2;
        }
    }
}
